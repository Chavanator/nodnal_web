# Especificación técnica inicial

## Principio

La arquitectura final debe decidirse después de auditar el sitio descargado localmente, los assets y las dependencias existentes. No iniciar un reemplazo destructivo antes de esa auditoría.

## Stack candidato

- **Frontend:** Astro + TypeScript para páginas de contenido rápidas y rutas ES/EN.
- **Interactividad:** componentes ligeros y CSS; incorporar un framework UI solo si el panel administrativo lo justifica.
- **Hosting:** Cloudflare Pages o Cloudflare Workers, según compatibilidad de SSR y APIs.
- **Backend/API:** Cloudflare Workers.
- **Base de datos:** Cloudflare D1 si el modelo relacional y las necesidades de consulta encajan.
- **Archivos:** assets estáticos versionados para el MVP o Cloudflare R2 si se necesita subida dinámica/gestión de archivos.
- **Email:** proveedor transaccional con dominio verificado, selección pendiente.
- **Scheduler:** Cloudflare Cron Triggers u otra solución compatible para recordatorios.
- **Pagos:** PayPal sandbox y webhooks validados desde servidor.
- **Pruebas:** unitarias para lógica de negocio; integración para API y flujos de pago; Playwright para recorridos end-to-end si el entorno disponible lo permite.

Estas son opciones a evaluar, no un compromiso final. Comparar costes, límites, complejidad y facilidad de operación antes de cerrar la decisión.

## Entidades de datos

Como mínimo:
- Event
- Registration
- Payment
- WaitlistEntry
- AdminUser o integración de autenticación equivalente
- EmailJob/NotificationLog para controlar recordatorios y evitar duplicados

Definir migraciones versionadas y restricciones de integridad.

## Autenticación y administración

- El panel administrativo requiere autenticación segura.
- Preferir un proveedor o mecanismo mantenido frente a crear criptografía propia.
- Aplicar autorización del lado servidor a cada operación.
- No confiar en que ocultar una ruta o botón proteja datos.
- Limitar acceso a datos de participantes por necesidad operativa.
- Definir recuperación de acceso y protección contra intentos repetidos.

## Tareas programadas

Recordatorios:
- Una semana antes.
- Un día antes.
- Solo inscripciones confirmadas.
- Zona horaria del evento.
- Idempotencia por inscripción, evento y tipo de recordatorio.
- Reintentos limitados y registro de fallos.
- No enviar recordatorios para eventos cancelados ni inscripciones canceladas.

## Entornos

- Local.
- Preview/demo.
- Producción.

Usar variables y secretos distintos por entorno. El entorno demo debe utilizar credenciales sandbox y contenido ficticio. No copiar datos personales reales al demo.

## Despliegue

- No cambiar DNS hasta aprobación explícita.
- Configurar dominio de preview y HTTPS.
- Documentar variables requeridas y pasos de despliegue.
- Verificar formularios, emails, logs y pagos sandbox antes de aprobar el demo.
- Definir rollback y backups antes de producción.

## Costes

Confirmar antes del lanzamiento:
- Plan de hosting.
- Base de datos/almacenamiento y límites.
- Proveedor de correo y volumen.
- Costes de dominio (si aplican), herramientas y servicios.
- Comisiones de PayPal/Venmo u otros proveedores.
- Mantenimiento, monitorización y backups.

## Auditoría inicial obligatoria

1. Identificar si el sitio local es una descarga estática o una base de código editable.
2. Inventariar assets y contenido.
3. Inspeccionar `package.json`, lockfile, scripts y configuración.
4. Revisar URLs actuales y posibles redirecciones.
5. Detectar formularios, analítica y enlaces externos existentes.
6. Recomendar stack final y registrar el motivo.
